import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, ScrollView, Dimensions, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const screenWidth = Dimensions.get('window').width;

// --- Componentes Reutilizables ---

// Componente para mostrar un dato específico (en la vista de detalle)
function Dato({ icon, label, value, color }) {
  return (
    <View style={styles.dato}>
      <Ionicons name={icon} size={22} color={color} style={{ marginRight: 10 }} />
      <Text style={styles.label}>{label}:</Text>
      <Text style={styles.value}>{value}</Text>
    </View>
  );
}

// Componente para mostrar un sensor en la tarjeta de la cuadrícula
function MiniSensor({ icon, label, value, color }) {
  return (
    <View style={styles.miniSensor}>
      <Ionicons name={icon} size={18} color={color} />
      <Text style={styles.miniLabel}>{label}:</Text>
      <Text style={styles.miniValue}>{value}</Text>
    </View>
  );
}

function DetalleCunaCompleta({ cuna, onDarAlta }) {
  const handlePress = () => {
    console.log('[DetalleCunaCompleta] Botón "Dar de alta" presionado para la cuna:', cuna.nombre);
    if (typeof onDarAlta === 'function') {
      onDarAlta(cuna);
    } else {
      console.error('[DetalleCunaCompleta] onDarAlta no es una función. Revisa las props.');
      Alert.alert('Error', 'La función para dar de alta no está disponible.');
    }
  };

  return (
    <View style={styles.detalleContainerCompleto}>
      <View style={styles.detalleHeader}>
        <Text style={styles.detalleTitle}>{cuna.nombre}</Text>
        <Text style={styles.detalleSub}>Asignada el {new Date(cuna.fechaAsig).toLocaleDateString()}</Text>
      </View>
      <View style={styles.detalleCard}>
        <Dato icon="thermometer" label="Temperatura" value={cuna.temperature} color="#FF5252" />
        <Dato icon="cloud" label="CO2" value={cuna.co2} color="#42A5F5" />
        <Dato icon="water" label="Humedad" value={cuna.humidity} color="#29B6F6" />
        <Dato icon="move" label="Movimiento" value={cuna.movement} color="#AB47BC" />
        <Dato icon="scale" label="Peso" value={cuna.weight} color="#7E57C2" />
        <Dato icon="checkmark-circle" label="Estado" value={cuna.status} color="#5D9C59" />
        <Dato icon="home" label="Cuarto" value={cuna.nombreCuarto} color="#4A2C8E" />
        <Dato icon="medkit" label="Hospital" value={cuna.nombreHospital} color="#4A2C8E" />
        
        <TouchableOpacity
          style={styles.botonDarAlta}
          onPress={handlePress}
        >
          <Ionicons name="log-out-outline" size={20} color="#fff" style={{ marginRight: 8 }} />
          <Text style={styles.botonTexto}>Dar de alta</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}


// --- Componente Principal ---

export default function CunasEnfermeroScreen({ userId }) {
  const [vista, setVista] = useState('grid');
  const [cunaSeleccionada, setCunaSeleccionada] = useState(null);
  const [cunas, setCunas] = useState([]);

  const API_URL = 'http://172.18.2.158:3000';

  const fetchCunas = async () => {
    if (userId) {
      console.log(`[fetchCunas] Obteniendo cunas para userId: ${userId}`);
      try {
        const response = await fetch(`${API_URL}/api/cunas/enfermero/${userId}`);
        
        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`Error HTTP! estado: ${response.status}, mensaje: ${errorText}`);
        }
        const data = await response.json();
        console.log('[fetchCunas] Datos recibidos para cunas:', data);

        const cunasFormateadas = data.map(cuna => ({
          idCuna: cuna.idCuna,
          nombre: cuna.nombre,
          temperature: '---',
          co2: '---',
          humidity: '---',
          movement: '---',
          weight: '---',
          status: cuna.Estado ? 'Ocupada' : 'Libre',
          fechaAsig: cuna.FechaAsig,
          nombreCuarto: cuna.nombreCuarto,
          nombreHospital: cuna.nombreHospital,
        }));

        setCunas(cunasFormateadas);
      } catch (error) {
        console.error("[fetchCunas] Error al obtener cunas:", error);
        Alert.alert("Error", "No se pudieron cargar las cunas. Por favor, inténtalo de nuevo.");
      }
    } else {
      console.log('[fetchCunas] userId no está disponible aún. Esperando...');
    }
  };

  useEffect(() => {
    fetchCunas();
  }, [userId]);

  const handleDarAlta = (cunaADarDeAlta) => {
  console.log('[handleDarAlta] Iniciando proceso para cuna:', cunaADarDeAlta);
  
  Alert.alert(
    "Confirmar Alta Médica",
    `¿Estás seguro de dar de alta al bebé en ${cunaADarDeAlta.nombre}?`,
    [
      {
        text: "Cancelar",
        style: "cancel"
      },
      {
        text: "Confirmar",
        onPress: async () => {
          try {
            const response = await fetch(`${API_URL}/api/cunas/dar-de-alta/${cunaADarDeAlta.idCuna}`, {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
            });

            if (!response.ok) {
              throw new Error('Error en la respuesta del servidor');
            }

            const result = await response.json();
            Alert.alert("Éxito", result.message);
            
            // Actualizar el estado local
            setCunas(prev => prev.filter(c => c.idCuna !== cunaADarDeAlta.idCuna));
            
          } catch (error) {
            console.error("Error al dar de alta:", error);
            Alert.alert("Error", "No se pudo completar el alta médica");
          }
        }
      }
    ]
  );
};

  const mostrarDetalle = (cuna) => {
    setCunaSeleccionada(cuna);
    setVista('detalle');
  };

  const volverAListado = () => {
    setVista('grid');
    setCunaSeleccionada(null);
  };

  if (vista === 'detalle' && cunaSeleccionada) {
    return (
      <ScrollView style={styles.container}>
        <DetalleCunaCompleta cuna={cunaSeleccionada} onDarAlta={handleDarAlta} />
        <TouchableOpacity style={styles.botonVolver} onPress={volverAListado}>
          <Ionicons name="arrow-back" size={18} color="#fff" style={{ marginRight: 6 }} />
          <Text style={styles.botonTexto}>Volver</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.headerTitle}>Cunas Asignadas</Text>

      {cunas.length === 0 && (
        <Text style={styles.noCunasText}>No tienes cunas asignadas actualmente.</Text>
      )}

      {cunas.length > 0 && cunas.length <= 2 && (
        <View>
          {cunas.map(cuna => (
            <DetalleCunaCompleta key={cuna.idCuna} cuna={cuna} onDarAlta={handleDarAlta} />
          ))}
        </View>
      )}

      {cunas.length > 2 && (
        <View style={styles.grid}>
          {cunas.map((cuna) => (
            <TouchableOpacity key={cuna.idCuna} style={styles.card} onPress={() => mostrarDetalle(cuna)}>
              <Text style={styles.cunaTitle}>{cuna.nombre}</Text>
              <MiniSensor icon="thermometer" label="Temp." value={cuna.temperature} color="#FF5252" />
              <MiniSensor icon="cloud" label="CO2" value={cuna.co2} color="#42A5F5" />
              <MiniSensor icon="scale" label="Peso" value={cuna.weight} color="#7E57C2" />
              <MiniSensor icon="checkmark-circle" label="Estado" value={cuna.status} color="#5D9C59" />
            </TouchableOpacity>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

// --- Estilos ---
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9F5FF', padding: 10 },
  headerTitle: { fontSize: 22, fontWeight: 'bold', color: '#4A2C8E', textAlign: 'center', marginBottom: 20 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  card: {
    width: (screenWidth / 2) - 20,
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 12,
    marginBottom: 15,
    shadowColor: '#7E57C2',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  cunaTitle: { fontSize: 16, fontWeight: 'bold', color: '#4A2C8E', marginBottom: 10, textAlign: 'center' },
  miniSensor: { flexDirection: 'row', alignItems: 'center', marginBottom: 5 },
  miniLabel: { marginLeft: 5, fontSize: 13, color: '#555', fontWeight: '600' },
  miniValue: { marginLeft: 5, fontSize: 13, fontWeight: 'bold', color: '#2c3e50' },
  dato: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  label: { fontSize: 16, color: '#4A2C8E', fontWeight: '600' },
  value: { fontSize: 16, marginLeft: 6, fontWeight: 'bold', color: '#333' },
  detalleHeader: { alignItems: 'center', marginBottom: 20, marginTop: 10 },
  detalleTitle: { fontSize: 24, fontWeight: 'bold', color: '#4A2C8E' },
  detalleSub: { fontSize: 14, color: '#777', marginTop: 4 },
  detalleCard: {
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 20,
    elevation: 5,
    shadowColor: '#7E57C2',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    marginHorizontal: 5,
  },
  detalleContainerCompleto: {
    marginBottom: 25,
  },
  botonVolver: {
    flexDirection: 'row',
    alignSelf: 'center',
    backgroundColor: '#4A2C8E',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 25,
    alignItems: 'center',
    elevation: 4,
    marginBottom: 40,
    marginTop: 10,
  },
  botonDarAlta: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#d9534f',
    paddingVertical: 12,
    borderRadius: 25,
    marginTop: 20,
    elevation: 3,
    shadowColor: '#d9534f',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  botonTexto: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  noCunasText: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 16,
    color: '#777',
    width: '100%',
  }
});
